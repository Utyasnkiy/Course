
module.exports = {
  secret: 'MY SECRET',
  DB_URI_DEV: 'mongodb://127.0.0.1:27017/internetmagazin_dev',
  DB_URI: 'mongodb://127.0.0.1:27017/internetmagazin'
};