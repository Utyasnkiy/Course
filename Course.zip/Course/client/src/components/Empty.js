import React from 'react';

const Empty = () => <p>Пусто</p>;


export default Empty;
