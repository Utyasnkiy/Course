// import React from 'react'
// import { Container, Row, Col } from 'reactstrap';

// const styles = {
//     backgroundColor: '#072a48',
//     paddingTop: '50px',
//     paddingBottom: '50px',
//     color: 'white',
//     textAlign: 'center'
// }
 
// const Footer = () => (
//   <div style={styles}>
//     <Container>
//       <Row>
//       </Row> 
//       <Row>
//         <Col md='4'>Instagram</Col>
//       </Row
//       <Row>
//       </Row>
//     </Container>
//   </div>    
// )

const Footer = () => null

export default Footer;