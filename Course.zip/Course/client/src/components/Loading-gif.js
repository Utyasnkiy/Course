import React from 'react'

const LoadingGif = () => <div style={{margin:'auto'}}><img src='/images/gifLoading.gif' alt="" /></div>

export default LoadingGif
